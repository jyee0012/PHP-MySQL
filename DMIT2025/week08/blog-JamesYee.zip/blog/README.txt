current problem:
when you specifically search a term then login, you will be redirected to an empty search page.